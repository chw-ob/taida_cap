# _*_coding : utf-8 _*_
# @Time : 2025/10/29 11:26
# @Author : 曾宪博
# @File : IT8818B
# @Project : Aipower_inst_drive
from visa import RM
from time import sleep



class IT8800:
    def __init__(self):
        self._insts = {}
    def _get_inst(self, addr):
        if self._insts.get(addr) is None:
            try:
                inst = RM.open_resource(addr)
                inst.timeout = 5000  # 5秒超时
                inst.write_termination = '\n'
                inst.read_termination = '\n'
                self._insts[addr] = inst
                print(f'IT8800电子负载[addr={addr}]已连接.')
            except Exception as e:
                print(f'连接IT8800失败: {str(e)}')
                return None
        return self._insts[addr]

    def close(self, addr):
        inst = self._get_inst(addr)
        if inst:
            inst.close()
            del self._insts[addr]
            print(f'IT8800[addr={addr}]连接已关闭.')

    def initialize(self, addr):
        """初始化设备"""
        inst = self._get_inst(addr)
        if not inst:
            return False

        try:
            inst.write('*RST')  # 重置设备
            sleep(1)
            # 设置远程模式
            inst.write('SYST:REM')
            # 查询设备信息
            idn = inst.query('*IDN?')
            print(f'IT8800设备信息: {idn.strip()}')
            return True
        except Exception as e:
            print(f'初始化IT8800失败: {str(e)}')
            return False

    def set_remote_mode(self, addr):
        """设置远程模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:REM')

    def set_local_mode(self, addr):
        """设置本地模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:LOC')

    def set_rwlock_mode(self, addr):
        """设置远程锁定模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:RWL')

    # ========== 输入控制命令 ==========

    def set_input_state(self, addr, state):
        """设置输入状态 ON/OFF"""
        state = int(state)
        inst = self._get_inst(addr)
        if inst:
            cmd = 'INP ON' if state else 'INP OFF'
            inst.write(cmd)

    def set_short_state(self, addr, state):
        """设置短路状态"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'INP:SHOR ON' if state else 'INP:SHOR OFF'
            inst.write(cmd)

    def clear_protection(self, addr):
        """清除保护状态"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('INP:PROT:CLE')

    # ========== 工作模式设置 ==========

    def set_mode_cc(self, addr):
        """设置为恒流模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC CURR')

    def set_mode_cv(self, addr):
        """设置为恒压模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC VOLT')

    def set_mode_cr(self, addr):
        """设置为恒阻模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC RES')

    def set_mode_cw(self, addr):
        """设置为恒功率模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC POW')

    def set_mode_list(self, addr):
        """设置为列表模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC:MODE LIST')

    def set_mode_fixed(self, addr):
        """设置为固定模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC:MODE FIX')

    # ========== CC模式设置 ==========

    def set_cc_current(self, addr, current):
        """设置CC模式电流值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR {current}')

    def set_cc_range(self, addr, range_val):
        """设置CC模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:RANG {range_val}')

    def set_cc_slew_rate(self, addr, slew_rate):
        """设置CC模式上升下降速率"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:SLEW {slew_rate}')

    def set_cc_protection(self, addr, state, level=None, delay=None):
        """设置CC模式过流保护"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'CURR:PROT:STAT ON' if state else 'CURR:PROT:STAT OFF'
                inst.write(cmd)
            if level is not None:
                inst.write(f'CURR:PROT:LEV {level}')
            if delay is not None:
                inst.write(f'CURR:PROT:DEL {delay}')

    # ========== CV模式设置 ==========

    def set_cv_voltage(self, addr, voltage):
        """设置CV模式电压值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT {voltage}')

    def set_cv_range(self, addr, range_val):
        """设置CV模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:RANG {range_val}')

    def set_cv_on_voltage(self, addr, voltage):
        """设置CV模式开始带载电压"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:ON {voltage}')

    # ========== CR模式设置 ==========

    def set_cr_resistance(self, addr, resistance):
        """设置CR模式电阻值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES {resistance}')

    def set_cr_range(self, addr, range_val):
        """设置CR模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES:RANG {range_val}')

    def set_cr_led_test(self, addr, state, vdrop=None):
        """设置CR模式LED测试"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'RES:LED ON' if state else 'RES:LED OFF'
                inst.write(cmd)
            if vdrop is not None:
                inst.write(f'RES:VDROP {vdrop}')

    # ========== CW模式设置 ==========

    def set_cw_power(self, addr, power):
        """设置CW模式功率值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW {power}')

    def set_cw_range(self, addr, range_val):
        """设置CW模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW:RANG {range_val}')

    def set_cw_protection(self, addr, state, level=None, delay=None):
        """设置CW模式过功率保护"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'POW:PROT:STAT ON' if state else 'POW:PROT:STAT OFF'
                inst.write(cmd)
            if level is not None:
                inst.write(f'POW:PROT {level}')
            if delay is not None:
                inst.write(f'POW:PROT:DEL {delay}')

    # ========== 动态模式设置 ==========

    def set_dynamic_cc(self, addr, mode, a_level, b_level, a_width=None, b_width=None):
        """
        设置CC动态模式
        mode: CONTinuous, PULSe, TOGGle
        """
        inst = self._get_inst(addr)
        if inst:
            # 先关闭瞬态
            inst.write('TRAN OFF')
            # 设置模式
            inst.write(f'CURR:TRAN:MODE {mode}')
            # 设置A/B电平
            inst.write(f'CURR:TRAN:ALEV {a_level}')
            inst.write(f'CURR:TRAN:BLEV {b_level}')
            # 设置脉宽（如果提供）
            if a_width is not None:
                inst.write(f'CURR:TRAN:AWID {a_width}')
            if b_width is not None:
                inst.write(f'CURR:TRAN:BWID {b_width}')
            # 开启瞬态
            inst.write('TRAN ON')

    def trigger_dynamic(self, addr):
        """触发动态操作"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('TRIG:IMM')

    # ========== 列表模式设置 ==========

    def setup_list_mode(self, addr, steps, levels, widths=None, slews=None, count=1):
        """
        设置列表模式
        steps: 步数
        levels: 电平列表
        widths: 宽度列表（秒）
        slews: 斜率列表
        count: 循环次数
        """
        inst = self._get_inst(addr)
        if inst:
            # 设置步数
            inst.write(f'LIST:STEP {steps}')
            # 设置循环次数
            inst.write(f'LIST:COUNT {count}')
            # 设置各步参数
            for i in range(steps):
                if i < len(levels):
                    inst.write(f'LIST:LEV {i + 1},{levels[i]}')
                if widths and i < len(widths):
                    inst.write(f'LIST:WID {i + 1},{widths[i]}')
                if slews and i < len(slews):
                    inst.write(f'LIST:SLEW {i + 1},{slews[i]}')
            # 设置为列表模式
            inst.write('FUNC:MODE LIST')

    # ========== 测量命令 ==========

    def measure_voltage(self, addr):
        """测量电压"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT?')
                # 处理可能的字符串格式，移除单位等
                value_str = response.strip().rstrip('V')
                return float(value_str)
            except Exception as e:
                print(f"测量电压错误: {e}")
                return 0.0  # 返回默认值而不是None
        return 0.0

    def measure_current(self, addr):
        """测量电流"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR?')
                value_str = response.strip().rstrip('A')
                return float(value_str)
            except Exception as e:
                print(f"测量电流错误: {e}")
                return 0.0
        return 0.0

    def measure_power(self, addr):
        """测量功率"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('FETCh:POWer?')
                value_str = response.strip().rstrip('W')
                return float(value_str)
            except Exception as e:
                print(f"测量功率错误: {e}")
                return 0.0
        return 0.0

    def measure_voltage_max(self, addr):
        """测量最大电压"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT:MAX?')
                value_str = response.strip().rstrip('V')
                return float(value_str)
            except Exception as e:
                print(f"测量最大电压错误: {e}")
                return 0.0
        return 0.0

    def measure_current_max(self, addr):
        """测量最大电流"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR:MAX?')
                value_str = response.strip().rstrip('A')
                return float(value_str)
            except Exception as e:
                print(f"测量最大电流错误: {e}")
                return 0.0
        return 0.0

    # ========== 状态查询 ==========

    def get_operation_status(self, addr):
        """获取操作状态"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:OPER:COND?')
                return int(response.strip())
            except:
                return None
        return None

    def get_questionable_status(self, addr):
        """获取查询状态"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:QUES:COND?')
                return int(response.strip())
            except:
                return None
        return None

    def get_error(self, addr):
        """获取错误信息"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('SYST:ERR?')
                return response.strip()
            except:
                return None
        return None

    # ========== 系统命令 ==========

    def reset(self, addr):
        """重置设备"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('*RST')
            sleep(1)

    def self_test(self, addr):
        """自检"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('*TST?')
                return int(response.strip()) == 0
            except:
                return False
        return False

    def save_setup(self, addr, location):
        """保存设置到指定位置(0-100)"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'*SAV {location}')

    def recall_setup(self, addr, location):
        """从指定位置调用设置"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'*RCL {location}')


# 测试代码
if __name__ == "__main__":
    def test_it8800():
        # 初始化控制器
        it8800 = IT8800()

        # 设备地址 - 根据实际连接修改
        instrument_addr = "USB0::0xFFFF::0x8800::600237011697230001::INSTR"  # 示例地址

        print("测试IT8800电子负载驱动...")

        # 测试初始化
        print("\n1. 测试初始化...")
        if it8800.initialize(instrument_addr):
            print("初始化成功")
        else:
            print("初始化失败")
            return

        # 测试CC模式
        print("\n2. 测试恒流模式...")
        it8800.set_mode_cc(instrument_addr)
        it8800.set_cc_current(instrument_addr, 1)  # 设置1.5A
        it8800.set_input_state(instrument_addr, True)  # 开启输入

        sleep(2)  # 增加等待时间，确保设置生效

        # 测量参数
        voltage = it8800.measure_voltage(instrument_addr)
        current = it8800.measure_current(instrument_addr)
        power = it8800.measure_power(instrument_addr)

        # 检查测量结果是否有效
        if voltage is not None and current is not None and power is not None:
            print(f"测量结果: {voltage:.3f}V, {current:.3f}A, {power:.3f}W")
        else:
            print("测量失败，返回默认值")
            print(f"测量结果: {voltage:.3f}V, {current:.3f}A, {power:.3f}W")

        # 测试动态模式（可选，注释掉如果不需要）
        # print("\n3. 测试动态CC模式...")
        # it8800.set_dynamic_cc(
        #     instrument_addr,
        #     mode='CONTinuous',
        #     a_level=1.0,    # 1A
        #     b_level=2.0,    # 2A
        #     a_width=0.01,   # 10ms
        #     b_width=0.01    # 10ms
        # )
        # it8800.trigger_dynamic(instrument_addr)
        # print("动态模式已启动")

        # 测试列表模式（可选，注释掉如果不需要）
        # print("\n4. 测试列表模式...")
        # levels = [1.0, 2.0, 1.5, 0.5]  # 电流电平序列
        # widths = [0.1, 0.2, 0.15, 0.05]  # 各步持续时间
        # it8800.setup_list_mode(instrument_addr, 4, levels, widths, count=10)
        # print("列表模式已设置")

        # 测试保护功能
        print("\n5. 测试过流保护...")
        it8800.set_cc_protection(instrument_addr, True, level=3.0, delay=0.1)
        print("过流保护已设置: 3A, 100ms延迟")

        # 测试状态查询
        print("\n6. 测试状态查询...")
        op_status = it8800.get_operation_status(instrument_addr)
        ques_status = it8800.get_questionable_status(instrument_addr)
        error = it8800.get_error(instrument_addr)
        print(f"操作状态: {op_status}, 查询状态: {ques_status}")
        print(f"错误信息: {error}")

        # 关闭输入
        it8800.set_input_state(instrument_addr, False)
        print("输入已关闭")

        # 重置设备
        print("\n7. 重置设备...")
        it8800.reset(instrument_addr)

        # 关闭连接
        print("\n8. 关闭连接...")
        it8800.close(instrument_addr)

        print("\n所有测试完成!")


    # 运行测试
    test_it8800()