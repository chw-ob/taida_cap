# _*_coding : utf-8 _*_
# @Time : 2025/10/30 13:15
# @Author : 曾宪博
# @File : IT8900
# @Project : Aipower_inst_drive
# _*_coding : utf-8 _*_
# @Time : 2025/10/29 11:26
# @Author : 曾宪博
# @File : IT8900
# @Project : Aipower_inst_drive
from visa import RM
from time import sleep


class IT8900:
    def __init__(self):
        self._insts = {}

    def _get_inst(self, addr):
        if self._insts.get(addr) is None:
            try:
                inst = RM.open_resource(addr)
                inst.timeout = 5000  # 5秒超时
                inst.write_termination = '\n'
                inst.read_termination = '\n'
                self._insts[addr] = inst
                print(f'IT8900直流电子负载[addr={addr}]已连接.')
            except Exception as e:
                print(f'连接IT8900失败: {str(e)}')
                return None
        return self._insts[addr]

    def close(self, addr):
        inst = self._get_inst(addr)
        if inst:
            inst.close()
            del self._insts[addr]
            print(f'IT8900[addr={addr}]连接已关闭.')

    def initialize(self, addr):
        """初始化设备"""
        inst = self._get_inst(addr)
        if not inst:
            return False

        try:
            inst.write('*RST')  # 重置设备
            sleep(1)
            # 设置远程模式
            inst.write('SYST:REM')
            # 查询设备信息
            idn = inst.query('*IDN?')
            print(f'IT8900设备信息: {idn.strip()}')
            return True
        except Exception as e:
            print(f'初始化IT8900失败: {str(e)}')
            return False

    # ========== 系统命令 ==========

    def set_remote_mode(self, addr):
        """设置远程模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:REM')

    def set_local_mode(self, addr):
        """设置本地模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:LOC')

    def set_rwlock_mode(self, addr):
        """设置远程锁定模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:RWL')

    def get_error(self, addr):
        """获取错误信息"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('SYST:ERR?')
                return response.strip()
            except:
                return None
        return None

    def clear_errors(self, addr):
        """清除错误序列"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('SYST:CLE')

    # ========== 输入控制命令 ==========

    def set_input_state(self, addr, state):
        """设置输入状态 ON/OFF"""
        state = int(state)
        inst = self._get_inst(addr)
        if inst:
            cmd = 'INP ON' if state else 'INP OFF'
            inst.write(cmd)

    def set_short_state(self, addr, state):
        """设置短路状态"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'INP:SHOR ON' if state else 'INP:SHOR OFF'
            inst.write(cmd)

    def clear_protection(self, addr):
        """清除保护状态"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('INP:PROT:CLE')

    def set_input_timer(self, addr, state, delay=None):
        """设置输入计时器"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'INP:TIM ON' if state else 'INP:TIM OFF'
                inst.write(cmd)
            if delay is not None:
                inst.write(f'INP:TIM:DEL {delay}')

    # ========== 工作模式设置 ==========

    def set_mode_cc(self, addr):
        """设置为恒流模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC CURR')

    def set_mode_cv(self, addr):
        """设置为恒压模式"""
        inst = self._insts.get(addr)
        if inst:
            inst.write('FUNC VOLT')

    def set_mode_cr(self, addr):
        """设置为恒阻模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC RES')

    def set_mode_cw(self, addr):
        """设置为恒功率模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC POW')

    def set_mode_fixed(self, addr):
        """设置为固定模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC:MODE FIX')

    def set_mode_list(self, addr):
        """设置为列表模式"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('FUNC:MODE LIST')

    # ========== CC模式设置 ==========

    def set_cc_current(self, addr, current):
        """设置CC模式电流值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR {current}')

    def set_cc_range(self, addr, range_val):
        """设置CC模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:RANG {range_val}')

    def set_cc_slew_rate(self, addr, slew_rate):
        """设置CC模式上升下降速率"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:SLEW {slew_rate}')

    def set_cc_slew_rate_positive(self, addr, slew_rate):
        """设置CC模式上升速率"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:SLEW:POS {slew_rate}')

    def set_cc_slew_rate_negative(self, addr, slew_rate):
        """设置CC模式下降速率"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'CURR:SLEW:NEG {slew_rate}')

    def set_cc_slew_rate_state(self, addr, state):
        """设置CC模式速率状态(0=高速,1=低速)"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'CURR:SLEW:STAT ON' if state else 'CURR:SLEW:STAT OFF'
            inst.write(cmd)

    def set_cc_protection(self, addr, state, level=None, delay=None):
        """设置CC模式过流保护"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'CURR:PROT:STAT ON' if state else 'CURR:PROT:STAT OFF'
                inst.write(cmd)
            if level is not None:
                inst.write(f'CURR:PROT {level}')
            if delay is not None:
                inst.write(f'CURR:PROT:DEL {delay}')

    def set_cc_high_low(self, addr, high=None, low=None):
        """设置CC模式电压判定上下限"""
        inst = self._get_inst(addr)
        if inst:
            if high is not None:
                inst.write(f'CURR:HIGH {high}')
            if low is not None:
                inst.write(f'CURR:LOW {low}')

    # ========== CV模式设置 ==========

    def set_cv_voltage(self, addr, voltage):
        """设置CV模式电压值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT {voltage}')

    def set_cv_range(self, addr, range_val):
        """设置CV模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:RANG {range_val}')

    def set_cv_range_auto(self, addr, state):
        """设置CV模式自动量程"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'VOLT:RANG:AUTO ON' if state else 'VOLT:RANG:AUTO OFF'
            inst.write(cmd)

    def set_cv_on_voltage(self, addr, voltage):
        """设置CV模式开始带载电压"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:ON {voltage}')

    def set_cv_latch(self, addr, state):
        """设置CV模式VON电压卸载类型"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'VOLT:LATCH ON' if state else 'VOLT:LATCH OFF'
            inst.write(cmd)

    def set_cv_current_limit(self, addr, current):
        """设置CV模式限流值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:ILIM {current}')

    def set_cv_slew_rate_state(self, addr, state):
        """设置CV模式速率状态(0=高速,1=低速)"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'VOLT:SLEW:STAT ON' if state else 'VOLT:SLEW:STAT OFF'
            inst.write(cmd)

    def set_cv_high_low(self, addr, high=None, low=None):
        """设置CV模式电流判定上下限"""
        inst = self._get_inst(addr)
        if inst:
            if high is not None:
                inst.write(f'VOLT:HIGH {high}')
            if low is not None:
                inst.write(f'VOLT:LOW {low}')

    # ========== CR模式设置 ==========

    def set_cr_resistance(self, addr, resistance):
        """设置CR模式电阻值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES {resistance}')

    def set_cr_range(self, addr, range_val):
        """设置CR模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES:RANG {range_val}')

    def set_cr_led_test(self, addr, state, vdrop=None):
        """设置CR模式LED测试"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'RES:LED ON' if state else 'RES:LED OFF'
                inst.write(cmd)
            if vdrop is not None:
                inst.write(f'RES:VDROP {vdrop}')

    def set_cr_current_limit(self, addr, current):
        """设置CR模式限流值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES:ILIM {current}')

    def set_cr_high_low(self, addr, high=None, low=None):
        """设置CR模式电压判定上下限"""
        inst = self._get_inst(addr)
        if inst:
            if high is not None:
                inst.write(f'RES:HIGH {high}')
            if low is not None:
                inst.write(f'RES:LOW {low}')

    # ========== CW模式设置 ==========

    def set_cw_power(self, addr, power):
        """设置CW模式功率值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW {power}')

    def set_cw_range(self, addr, range_val):
        """设置CW模式量程"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW:RANG {range_val}')

    def set_cw_protection(self, addr, state, level=None, delay=None):
        """设置CW模式过功率保护"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'POW:PROT:STAT ON' if state else 'POW:PROT:STAT OFF'
                inst.write(cmd)
            if level is not None:
                inst.write(f'POW:PROT {level}')
            if delay is not None:
                inst.write(f'POW:PROT:DEL {delay}')

    def set_cw_config(self, addr, power):
        """设置CW模式硬件功率保护值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW:CONF {power}')

    def set_cw_current_limit(self, addr, current):
        """设置CW模式限流值"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW:ILIM {current}')

    def set_cw_high_low(self, addr, high=None, low=None):
        """设置CW模式电压判定上下限"""
        inst = self._get_inst(addr)
        if inst:
            if high is not None:
                inst.write(f'POW:HIGH {high}')
            if low is not None:
                inst.write(f'POW:LOW {low}')

    # ========== 动态模式设置 ==========

    def set_dynamic_cc(self, addr, mode, a_level, b_level, a_width=None, b_width=None):
        """
        设置CC动态模式
        mode: CONTinuous, PULSe, TOGGle
        """
        inst = self._get_inst(addr)
        if inst:
            # 设置模式
            inst.write(f'CURR:TRAN:MODE {mode}')
            # 设置A/B电平
            inst.write(f'CURR:TRAN:ALEV {a_level}')
            inst.write(f'CURR:TRAN:BLEV {b_level}')
            # 设置脉宽（如果提供）
            if a_width is not None:
                inst.write(f'CURR:TRAN:AWID {a_width}')
            if b_width is not None:
                inst.write(f'CURR:TRAN:BWID {b_width}')
            # 开启瞬态
            inst.write('TRAN ON')

    def set_dynamic_cv(self, addr, mode, a_level, b_level, a_width=None, b_width=None):
        """
        设置CV动态模式
        mode: CONTinuous, PULSe, TOGGle
        """
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'VOLT:TRAN:MODE {mode}')
            inst.write(f'VOLT:TRAN:ALEV {a_level}')
            inst.write(f'VOLT:TRAN:BLEV {b_level}')
            if a_width is not None:
                inst.write(f'VOLT:TRAN:AWID {a_width}')
            if b_width is not None:
                inst.write(f'VOLT:TRAN:BWID {b_width}')
            inst.write('TRAN ON')

    def set_dynamic_cr(self, addr, mode, a_level, b_level, a_width=None, b_width=None):
        """
        设置CR动态模式
        mode: CONTinuous, PULSe, TOGGle
        """
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'RES:TRAN:MODE {mode}')
            inst.write(f'RES:TRAN:ALEV {a_level}')
            inst.write(f'RES:TRAN:BLEV {b_level}')
            if a_width is not None:
                inst.write(f'RES:TRAN:AWID {a_width}')
            if b_width is not None:
                inst.write(f'RES:TRAN:BWID {b_width}')
            inst.write('TRAN ON')

    def set_dynamic_cw(self, addr, mode, a_level, b_level, a_width=None, b_width=None):
        """
        设置CW动态模式
        mode: CONTinuous, PULSe, TOGGle
        """
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'POW:TRAN:MODE {mode}')
            inst.write(f'POW:TRAN:ALEV {a_level}')
            inst.write(f'POW:TRAN:BLEV {b_level}')
            if a_width is not None:
                inst.write(f'POW:TRAN:AWID {a_width}')
            if b_width is not None:
                inst.write(f'POW:TRAN:BWID {b_width}')
            inst.write('TRAN ON')

    def set_transient_state(self, addr, state):
        """设置瞬态状态"""
        inst = self._get_inst(addr)
        if inst:
            cmd = 'TRAN ON' if state else 'TRAN OFF'
            inst.write(cmd)

    # ========== 触发命令 ==========

    def trigger_immediate(self, addr):
        """立即触发"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('TRIG:IMM')

    def set_trigger_source(self, addr, source):
        """设置触发源"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'TRIG:SOUR {source}')

    def set_trigger_timer(self, addr, timer):
        """设置触发定时器"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'TRIG:TIM {timer}')

    # ========== 列表模式设置 ==========

    def setup_list_mode(self, addr, steps, levels, slews=None, widths=None, count=1, range_val=None):
        """
        设置列表模式
        steps: 步数
        levels: 电平列表
        slews: 斜率列表
        widths: 宽度列表（秒）
        count: 循环次数
        range_val: 量程
        """
        inst = self._get_inst(addr)
        if inst:
            # 设置步数
            inst.write(f'LIST:STEP {steps}')
            # 设置循环次数
            inst.write(f'LIST:COUNT {count}')
            # 设置量程（如果提供）
            if range_val is not None:
                inst.write(f'LIST:RANG {range_val}')
            # 设置各步参数
            for i in range(steps):
                if i < len(levels):
                    inst.write(f'LIST:LEV {i + 1},{levels[i]}')
                if slews and i < len(slews):
                    inst.write(f'LIST:SLEW {i + 1},{slews[i]}')
                if widths and i < len(widths):
                    inst.write(f'LIST:WID {i + 1},{widths[i]}')
            # 设置为列表模式
            inst.write('FUNC:MODE LIST')

    def set_list_slow_rate(self, addr, rate):
        """设置列表模式速率(LOW/HIGH)"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'LIST:SLOW {rate}')

    def save_list(self, addr, location):
        """保存列表到指定位置(1-7)"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'LIST:SAV {location}')

    def recall_list(self, addr, location):
        """从指定位置调用列表"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'LIST:RCL {location}')

    # ========== 电池测试功能 ==========

    def set_battery_test(self, addr, state, stop_voltage=None, stop_capacity=None, stop_time=None):
        """设置电池测试"""
        inst = self._get_inst(addr)
        if inst:
            if state is not None:
                cmd = 'BATT ON' if state else 'BATT OFF'
                inst.write(cmd)
            if stop_voltage is not None:
                inst.write(f'BATT:STOP:VOLT {stop_voltage}')
            if stop_capacity is not None:
                inst.write(f'BATT:STOP:CAP {stop_capacity}')
            if stop_time is not None:
                inst.write(f'BATT:STOP:TIME {stop_time}')

    def reset_battery(self, addr):
        """重置电池测试"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('BATT:RES')

    def get_battery_time(self, addr):
        """获取电池测试时间"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('BATT:TIME?')
                return float(response.strip())
            except:
                return 0.0
        return 0.0

    # ========== 测量命令 ==========

    def measure_voltage(self, addr):
        """测量电压"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT?')
                value_str = response.strip().rstrip('V')
                return float(value_str)
            except Exception as e:
                print(f"测量电压错误: {e}")
                return 0.0
        return 0.0

    def measure_current(self, addr):
        """测量电流"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR?')
                value_str = response.strip().rstrip('A')
                return float(value_str)
            except Exception as e:
                print(f"测量电流错误: {e}")
                return 0.0
        return 0.0

    def measure_power(self, addr):
        """测量功率"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('FETC:POW?')
                value_str = response.strip().rstrip('W')
                return float(value_str)
            except Exception as e:
                print(f"测量功率错误: {e}")
                return 0.0
        return 0.0

    def measure_voltage_max(self, addr):
        """测量最大电压"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT:MAX?')
                value_str = response.strip().rstrip('V')
                return float(value_str)
            except Exception as e:
                print(f"测量最大电压错误: {e}")
                return 0.0
        return 0.0

    def measure_current_max(self, addr):
        """测量最大电流"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR:MAX?')
                value_str = response.strip().rstrip('A')
                return float(value_str)
            except Exception as e:
                print(f"测量最大电流错误: {e}")
                return 0.0
        return 0.0

    def measure_voltage_min(self, addr):
        """测量最小电压"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT:MIN?')
                value_str = response.strip().rstrip('V')
                return float(value_str)
            except Exception as e:
                print(f"测量最小电压错误: {e}")
                return 0.0
        return 0.0

    def measure_current_min(self, addr):
        """测量最小电流"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR:MIN?')
                value_str = response.strip().rstrip('A')
                return float(value_str)
            except Exception as e:
                print(f"测量最小电流错误: {e}")
                return 0.0
        return 0.0

    def measure_capacity(self, addr):
        """测量电池容量"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CAP?')
                return float(response.strip())
            except Exception as e:
                print(f"测量容量错误: {e}")
                return 0.0
        return 0.0

    def measure_temperature(self, addr):
        """测量温度"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:TEMP?')
                return float(response.strip())
            except Exception as e:
                print(f"测量温度错误: {e}")
                return 0.0
        return 0.0

    def measure_time(self, addr):
        """测量时间"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:TIME?')
                return float(response.strip())
            except Exception as e:
                print(f"测量时间错误: {e}")
                return 0.0
        return 0.0

    def measure_voltage_ripple(self, addr):
        """测量电压纹波"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:VOLT:RIPP?')
                return float(response.strip())
            except Exception as e:
                print(f"测量电压纹波错误: {e}")
                return 0.0
        return 0.0

    def measure_current_ripple(self, addr):
        """测量电流纹波"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('MEAS:CURR:RIPP?')
                return float(response.strip())
            except Exception as e:
                print(f"测量电流纹波错误: {e}")
                return 0.0
        return 0.0

    # ========== 状态查询 ==========

    def get_operation_status(self, addr):
        """获取操作状态"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:OPER:COND?')
                return int(response.strip())
            except:
                return None
        return None

    def get_questionable_status(self, addr):
        """获取查询状态"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:QUES:COND?')
                return int(response.strip())
            except:
                return None
        return None

    def get_operation_event(self, addr):
        """获取操作事件"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:OPER:EVEN?')
                return int(response.strip())
            except:
                return None
        return None

    def get_questionable_event(self, addr):
        """获取查询事件"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('STAT:QUES:EVEN?')
                return int(response.strip())
            except:
                return None
        return None

    # ========== 系统命令 ==========

    def reset(self, addr):
        """重置设备"""
        inst = self._get_inst(addr)
        if inst:
            inst.write('*RST')
            sleep(1)

    def self_test(self, addr):
        """自检"""
        inst = self._get_inst(addr)
        if inst:
            try:
                response = inst.query('*TST?')
                return int(response.strip()) == 0
            except:
                return False
        return False

    def save_setup(self, addr, location):
        """保存设置到指定位置(1-100)"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'*SAV {location}')

    def recall_setup(self, addr, location):
        """从指定位置调用设置"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'*RCL {location}')

    def set_power_on_setup(self, addr, mode):
        """设置上电状态(RST/SAV0)"""
        inst = self._get_inst(addr)
        if inst:
            inst.write(f'SYST:POS {mode}')


# 测试代码
if __name__ == "__main__":
    def test_it8900():
        # 初始化控制器
        it8900 = IT8900()

        # 设备地址 - 根据实际连接修改
        instrument_addr = "USB0::0xFFFF::0x8900::600237011697230002::INSTR"

        print("测试IT8900直流电子负载驱动...")

        # 测试初始化
        print("\n1. 测试初始化...")
        if it8900.initialize(instrument_addr):
            print("初始化成功")
        else:
            print("初始化失败")
            return

        # 测试CC模式
        print("\n2. 测试恒流模式...")
        it8900.set_mode_cc(instrument_addr)
        it8900.set_cc_current(instrument_addr, 1.0)  # 设置1A
        it8900.set_input_state(instrument_addr, True)  # 开启输入

        sleep(2)

        # 测量参数
        voltage = it8900.measure_voltage(instrument_addr)
        current = it8900.measure_current(instrument_addr)
        power = it8900.measure_power(instrument_addr)

        print(f"测量结果: {voltage:.3f}V, {current:.3f}A, {power:.3f}W")

        # 测试动态模式
        print("\n3. 测试动态CC模式...")
        it8900.set_dynamic_cc(
            instrument_addr,
            mode='CONT',
            a_level=1.0,
            b_level=2.0,
            a_width=0.01,
            b_width=0.01
        )
        it8900.trigger_immediate(instrument_addr)
        print("动态模式已启动")

        # 测试列表模式
        print("\n4. 测试列表模式...")
        levels = [1.0, 2.0, 1.5, 0.5]
        widths = [0.1, 0.2, 0.15, 0.05]
        it8900.setup_list_mode(instrument_addr, 4, levels, widths=widths, count=10)
        print("列表模式已设置")

        # 测试电池功能
        print("\n5. 测试电池测试功能...")
        it8900.set_battery_test(
            instrument_addr,
            state=True,
            stop_voltage=4.8,
            stop_capacity=1.2,
            stop_time=4000
        )
        print("电池测试已设置")

        # 测试保护功能
        print("\n6. 测试保护功能...")
        it8900.set_cc_protection(instrument_addr, True, level=3.0, delay=0.1)
        it8900.set_cw_protection(instrument_addr, True, level=50.0, delay=0.2)
        print("保护功能已设置")

        # 测试状态查询
        print("\n7. 测试状态查询...")
        op_status = it8900.get_operation_status(instrument_addr)
        ques_status = it8900.get_questionable_status(instrument_addr)
        error = it8900.get_error(instrument_addr)
        print(f"操作状态: {op_status}, 查询状态: {ques_status}")
        print(f"错误信息: {error}")

        # 关闭输入
        it8900.set_input_state(instrument_addr, False)
        print("输入已关闭")

        # 重置设备
        print("\n8. 重置设备...")
        it8900.reset(instrument_addr)

        # 关闭连接
        print("\n9. 关闭连接...")
        it8900.close(instrument_addr)

        print("\n所有测试完成!")


    # 运行测试
    test_it8900()