
import pyvisa as visa


RM = visa.ResourceManager()

V_source = 'USB0::0x1AB1::0x0E11::DL3A244401050::INSTR'
Load = 'USB0::0xFFFF::0x8800::600237011697230001::INSTR'
