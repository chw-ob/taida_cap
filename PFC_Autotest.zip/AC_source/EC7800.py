# _*_coding : utf-8 _*_
# @Time : 2025/10/30 12:43
# @Author : 曾宪博
# @File : EC7800
# @Project : Aipower_inst_drive
from visa import RM
from time import sleep

class EC7800():
    def __init__(self):
        '''定义一个字典，来存放对象，确保一个地址只会有一个对象'''
        self._insts = {}

    def _getInst(self, addr):
        '''如果地址对应的仪器不存在，则创建一个'''
        if self._insts.get(addr) is None:
            inst = RM().open_resource(addr)
            inst.timeout = 5000  # 5秒超时
            inst.read_termination = '\n'  # 终止符根据EC7800要求设置
            inst.write_termination = '\n'
            self._insts[addr] = inst
            print('交流电源[EC7800, addr={0}, inst_id={1}].'.format(addr, id(inst)))
        return self._insts[addr]

    def initialize(self, addr):
        '''初始化仪器，查询IDN信息'''
        inst = self._getInst(addr)
        re = ''
        try:
            re = inst.query('*IDN?')
        except Exception as e:
            print(f"仪器连接错误: {e}")
            return False
        if len(re) != 0:
            print('EC7800交流电源厂家信息：', re.strip())
            return True
        else:
            return False

    def reset(self, addr):
        '''恢复出厂设置'''
        inst = self._getInst(addr)
        inst.write('*RST')
        sleep(3)  # 等待复位完成

    def setOutput(self, addr, state):
        '''设置输出状态 ON/OFF'''
        inst = self._getInst(addr)
        if state.upper() in ['ON', '1']:
            inst.write('OUTPut:STATe ON')
        elif state.upper() in ['OFF', '0']:
            inst.write('OUTPut:STATe OFF')

    def getOutputState(self, addr):
        '''查询输出状态'''
        inst = self._getInst(addr)
        re = inst.query('OUTPut:STATe?')
        return 'ON' if re.strip() == '1' else 'OFF'

    def setVoltage(self, addr, voltage):
        '''设置输出电压(V)'''
        inst = self._getInst(addr)
        inst.write('SOURce:VOLTage {:.3f}'.format(float(voltage)))

    def setCurrent(self, addr, current):
        '''设置输出电流限制(A)'''
        inst = self._getInst(addr)
        inst.write('SOURce:CURRent {:.3f}'.format(float(current)))

    def setFrequency(self, addr, frequency):
        '''设置输出频率(Hz)'''
        inst = self._getInst(addr)
        inst.write('SOURce:FREQuency {:.2f}'.format(float(frequency)))

    def setPhase(self, addr, phase):
        '''设置相位(度)'''
        inst = self._getInst(addr)
        inst.write('SOURce:PHASe {:.1f}'.format(float(phase)))

    def getVoltageSetting(self, addr):
        '''查询设定的电压值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:VOLTage?')
        return float(re)

    def getCurrentSetting(self, addr):
        '''查询设定的电流值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:CURRent?')
        return float(re)

    def getFrequencySetting(self, addr):
        '''查询设定的频率值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:FREQuency?')
        return float(re)

    def measureVoltage(self, addr):
        '''测量实际输出电压'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:VOLTage?')
        return float(re)

    def measureCurrent(self, addr):
        '''测量实际输出电流'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:CURRent?')
        return float(re)

    def measurePower(self, addr):
        '''测量实际输出功率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:POWer?')
        return float(re)

    def measurePfactor(self, addr):
        '''测量实际输出功率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:POWer:PFACtor?')
        return float(re)

    def measureFrequency(self, addr):
        '''测量实际输出频率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:FREQuency?')
        return float(re)

    def setOVP(self, addr, voltage):
        '''设置过压保护点(V)'''
        inst = self._getInst(addr)
        inst.write('VOLTage:PROTection {:.3f}'.format(float(voltage)))

    def setOCP(self, addr, current):
        '''设置过流保护点(A)'''
        inst = self._getInst(addr)
        inst.write('CURRent:PROTection {:.3f}'.format(float(current)))

    def getOVP(self, addr):
        '''查询过压保护点'''
        inst = self._getInst(addr)
        re = inst.query('VOLTage:PROTection?')
        return float(re)

    def getOCP(self, addr):
        '''查询过流保护点'''
        inst = self._getInst(addr)
        re = inst.query('CURRent:PROTection?')
        return float(re)

    def clearProtection(self, addr):
        '''清除保护状态'''
        inst = self._getInst(addr)
        inst.write('OUTPut:PROTection:CLEar')

    def getSystemErrors(self, addr):
        '''查询系统错误信息'''
        inst = self._getInst(addr)
        errors = []
        while True:
            re = inst.query('SYSTem:ERRor?')
            if re.strip() == '0,"No error"':
                break
            errors.append(re.strip())
        return errors

    def clearStatus(self, addr):
        '''清除状态寄存器'''
        inst = self._getInst(addr)
        inst.write('*CLS')

    # EC7800特有功能
    def setVoltageRange(self, addr, range_val):
        '''设置电压量程'''
        inst = self._getInst(addr)
        inst.write('SOURce:VOLTage:RANGe {}'.format(range_val))

    def setCurrentRange(self, addr, range_val):
        '''设置电流量程'''
        inst = self._getInst(addr)
        inst.write('SOURce:CURRent:RANGe {}'.format(range_val))

    def setPowerOnState(self, addr, state):
        '''设置上电状态'''
        inst = self._getInst(addr)
        if state.upper() in ['ON', '1']:
            inst.write('OUTPut:PON 1')
        else:
            inst.write('OUTPut:PON 0')

    def setSyncSource(self, addr, source):
        '''设置同步源'''
        inst = self._getInst(addr)
        if source.upper() in ['INT', 'INTERNAL']:
            inst.write('SOURce:ROSCillator:SOURce INT')
        elif source.upper() in ['EXT', 'EXTERNAL']:
            inst.write('SOURce:ROSCillator:SOURce EXT')

    def saveState(self, addr, location):
        '''保存仪器状态'''
        inst = self._getInst(addr)
        inst.write('*SAV {}'.format(int(location)))

    def recallState(self, addr, location):
        '''调用保存的状态'''
        inst = self._getInst(addr)
        inst.write('*RCL {}'.format(int(location)))


if __name__ == "__main__":
    def test_ec7800():
        # 仪器地址（根据实际连接的IP地址修改）
        instrument_addr = "TCPIP0::172.16.5.126::2268::SOCKET"  # LAN连接示例

        # 创建驱动实例
        ec7800 = EC7800()

        # 1. 初始化仪器
        if not ec7800.initialize(instrument_addr):
            print("EC7800仪器连接失败，请检查地址和连接！")
            return

        # 2. 复位仪器（可选）
        ec7800.reset(instrument_addr)

        # 3. 设置输出参数
        print("\n设置输出参数...")
        ec7800.setVoltage(instrument_addr, 220.0)  # 220V
        ec7800.setCurrent(instrument_addr, 5.0)    # 5A
        ec7800.setFrequency(instrument_addr, 50.0) # 50Hz

        # 4. 设置保护点
        ec7800.setOVP(instrument_addr, 250.0)  # 过压保护250V
        ec7800.setOCP(instrument_addr, 6.0)    # 过流保护6A

        # 5. 开启输出
        print("开启输出...")
        ec7800.setOutput(instrument_addr, 'ON')
        sleep(2)  # 等待输出稳定

        # 6. 测量实际输出
        voltage = ec7800.measureVoltage(instrument_addr)
        current = ec7800.measureCurrent(instrument_addr)
        power = ec7800.measurePower(instrument_addr)
        frequency = ec7800.measureFrequency(instrument_addr)

        print(f"实际输出电压: {voltage:.2f} V")
        print(f"实际输出电流: {current:.3f} A")
        print(f"实际输出功率: {power:.2f} W")
        print(f"实际输出频率: {frequency:.2f} Hz")

        # 7. 关闭输出
        print("关闭输出...")
        ec7800.setOutput(instrument_addr, 'OFF')

        # 8. 检查系统错误
        errors = ec7800.getSystemErrors(instrument_addr)
        if errors:
            print("系统错误信息:", errors)
        else:
            print("无系统错误")

        # 9. 清除状态
        ec7800.clearStatus(instrument_addr)
        print("\nEC7800测试完成！")

    test_ec7800()