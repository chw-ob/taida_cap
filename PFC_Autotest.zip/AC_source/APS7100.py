from visa import RM
from time import sleep


class APS7100():
    def __init__(self):
        '''定义一个字典，来存放对象，确保一个地址只会有一个对象'''
        self._insts = {}

    def _getInst(self, addr):
        '''如果地址对应的仪器不存在，则创建一个'''
        if self._insts.get(addr) is None:
            inst = RM.open_resource(addr)
            inst.timeout = 3000  # 3秒超时
            inst.read_termination = '\n'  # 终止符根据仪器要求设置
            inst.write_termination = '\n'
            self._insts[addr] = inst
            print('交流电源[APS-7100, addr={0}, inst_id={1}].'.format(addr, id(inst)))
        return self._insts[addr]

    def initialize(self, addr):
        '''初始化仪器，查询IDN信息'''
        inst = self._getInst(addr)
        re = ''
        try:
            re = inst.query('*IDN?')
        except:
            pass
        if len(re) != 0:
            print('交流电源厂家信息：', re)
            return True
        else:
            return False

    def reset(self, addr):
        '''恢复出厂设置'''
        inst = self._getInst(addr)
        inst.write('*RST')
        sleep(1)  # 等待复位完成

    def setOutput(self, addr, state):
        '''设置输出状态 ON/OFF'''
        inst = self._getInst(addr)
        if state.upper() in ['ON', '1']:
            inst.write('OUTPut ON')
        elif state.upper() in ['OFF', '0']:
            inst.write('OUTPut OFF')

    def getOutputState(self, addr):
        '''查询输出状态'''
        inst = self._getInst(addr)
        re = inst.query('OUTPut?')
        return 'ON' if re.strip() == '1' else 'OFF'

    def set_voltage(self, addr, voltage):
        """设置输出电压(V)，自动选择量程"""
        inst = self._getInst(addr)
        vol = float(voltage)
        if inst:
            # 根据电压值自动选择合适的量程
            if vol <= 155:
                range_cmd = "R155"
            elif vol <= 310:
                range_cmd = "R310"
            else:
                range_cmd = "R600"

            # 设置量程
            inst.write(f'VOLT:RANG {range_cmd}')
            # 设置电压值
            inst.write(f'VOLT {vol:.3f}')

    def setCurrent(self, addr, current):
        '''设置输出电流限制(A)'''
        inst = self._getInst(addr)
        cur = float(current)
        inst.write(':CURRent:LIMit:RMS {:.3f}'.format(cur))

    def setFrequency(self, addr, frequency):
        '''设置输出频率(Hz)'''
        inst = self._getInst(addr)
        inst.write('SOURce:FREQuency {:.2f}'.format(float(frequency)))

    def setPhase(self, addr, phase):
        '''设置相位(度)'''
        inst = self._getInst(addr)
        inst.write('SOURce:PHASe {:.1f}'.format(float(phase)))

    def getVoltageSetting(self, addr):
        '''查询设定的电压值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:VOLTage?')
        return float(re)

    def getCurrentSetting(self, addr):
        '''查询设定的电流值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:CURRent?')
        return float(re)

    def getFrequencySetting(self, addr):
        '''查询设定的频率值'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:FREQuency?')
        return float(re)

    def measureVoltage(self, addr):
        '''测量实际输出电压'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:VOLTage?')
        return float(re)

    def measureCurrent(self, addr):
        '''测量实际输出电流'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:CURRent?')
        return float(re)

    def measurePower(self, addr):
        '''测量实际输出功率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:POWer?')
        return float(re)
    def measurePfactor(self, addr):
        '''测量实际输出功率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:POWer:PFACtor?')
        return float(re)

    def measureFrequency(self, addr):
        '''测量实际输出频率'''
        inst = self._getInst(addr)
        re = inst.query('MEASure:FREQuency?')
        return float(re)

    def setOVP(self, addr, voltage):
        '''设置过压保护点(V)'''
        inst = self._getInst(addr)
        inst.write('SOURce:VOLTage:PROTection {:.3f}'.format(float(voltage)))

    def setOCP(self, addr, current):
        '''设置过流保护点(A)'''
        inst = self._getInst(addr)
        inst.write('SOURce:CURRent:PROTection {:.3f}'.format(float(current)))

    def getOVP(self, addr):
        '''查询过压保护点'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:VOLTage:PROTection?')
        return float(re)

    def getOCP(self, addr):
        '''查询过流保护点'''
        inst = self._getInst(addr)
        re = inst.query('SOURce:CURRent:PROTection?')
        return float(re)

    def clearProtection(self, addr):
        '''清除保护状态'''
        inst = self._getInst(addr)
        inst.write('SOURce:VOLTage:PROTection:CLEar')
        inst.write('SOURce:CURRent:PROTection:CLEar')

    def getSystemErrors(self, addr):
        '''查询系统错误信息'''
        inst = self._getInst(addr)
        errors = []
        while True:
            re = inst.query('SYSTem:ERRor?')
            if re.strip() == '0,"No error"':
                break
            errors.append(re.strip())
        return errors

    def clearStatus(self, addr):
        '''清除状态寄存器'''
        inst = self._getInst(addr)
        inst.write('*CLS')


if __name__ == "__main__":
    def test_aps7100():
        # 仪器地址（根据实际连接的IP地址修改）
        instrument_addr = "TCPIP0::172.16.5.125::2268::SOCKET"  # LAN连接示例

        # 创建驱动实例
        aps7100 = APS7100()

        # 1. 初始化仪器
        if not aps7100.initialize(instrument_addr):
            print("仪器连接失败，请检查地址和连接！")
            return

        # 2. 复位仪器（可选）
        aps7100.reset(instrument_addr)

        # 3. 设置输出参数
        print("\n设置输出参数...")
        aps7100.setVoltage(instrument_addr, 140.0)  # 220V
        aps7100.setCurrent(instrument_addr, 7.0)    # 5A
        aps7100.setFrequency(instrument_addr, 51.0) # 50Hz

        # 4. 设置保护点
        aps7100.setOVP(instrument_addr, 150.0)  # 过压保护250V
        aps7100.setOCP(instrument_addr, 8.0)    # 过流保护6A

        # # 5. 开启输出
        # print("开启输出...")
        # aps7100.setOutput(instrument_addr, 'ON')
        # sleep(2)  # 等待输出稳定

        # 6. 测量实际输出
        voltage = aps7100.measureVoltage(instrument_addr)
        current = aps7100.measureCurrent(instrument_addr)
        power = aps7100.measurePower(instrument_addr)
        frequency = aps7100.measurePfactor(instrument_addr)

        print(f"实际输出电压: {voltage:.2f} V")
        print(f"实际输出电流: {current:.3f} A")
        print(f"实际输出功率: {power:.2f} W")
        print(f"实际输出频率: {frequency:.2f} Hz")

        # 7. 关闭输出
        print("关闭输出...")
        aps7100.setOutput(instrument_addr, 'OFF')
        # 8. 检查系统错误
        # errors = aps7100.getSystemErrors(instrument_addr)
        # if errors:
        #     print("系统错误信息:", errors)
        # else:
        #     print("无系统错误")

        # 9. 清除状态
        aps7100.clearStatus(instrument_addr)
        print("\n测试完成！")

    test_aps7100()