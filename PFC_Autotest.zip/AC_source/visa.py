
import pyvisa as visa


RM = visa.ResourceManager()

V_source = 'TCPIP0::172.16.5.125::2268::SOCKET'
Load = 'USB0::0x1AB1::0x0E11::DL3A244401050::INSTR'
